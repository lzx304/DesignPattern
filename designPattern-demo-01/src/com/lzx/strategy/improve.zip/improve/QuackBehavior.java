package com.lzx.strategy.improve;

/**
 * @author <a href="mailto:luozhenxing@wxchina.com">lzx</a>
 * @version 1.0.0
 * @Description
 * @date 2022/11/6 22:09:54
 */
public interface QuackBehavior {
    void quack();//子类实现
}
